package com.reyansh.audio.audioplayer.free.Dialogs;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;

/**
 * Created by REYANSH on 6/26/2017.
 */

public class OpenSettingsDialog extends DialogFragment {

    @Override
    public void onSaveInstanceState(Bundle outState) {
    }
}
