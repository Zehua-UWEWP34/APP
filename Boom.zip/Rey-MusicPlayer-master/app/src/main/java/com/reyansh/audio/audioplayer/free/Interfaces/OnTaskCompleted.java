package com.reyansh.audio.audioplayer.free.Interfaces;

/**
 * Created by REYANSH on 05/09/2016.
 */
public interface OnTaskCompleted {
    void onSongDeleted();
}
