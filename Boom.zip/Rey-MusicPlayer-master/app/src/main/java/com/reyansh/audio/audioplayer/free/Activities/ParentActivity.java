package com.reyansh.audio.audioplayer.free.Activities;

import android.support.v7.app.AppCompatActivity;

public class ParentActivity extends AppCompatActivity {



}
