package com.reyansh.audio.audioplayer.free.Interfaces;

/**
 * Created by REYANSH on 4/19/2017.
 */

public interface OnScrolledListener {
    void onScrolledUp();

    void onScrolledDown();
}
