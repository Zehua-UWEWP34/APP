package com.reyansh.audio.audioplayer.free.Setting;

import android.preference.PreferenceFragment;

/**
 * Created by REYANSH on 8/16/2017.
 */

public class TabSettingsFragment extends PreferenceFragment {

}
