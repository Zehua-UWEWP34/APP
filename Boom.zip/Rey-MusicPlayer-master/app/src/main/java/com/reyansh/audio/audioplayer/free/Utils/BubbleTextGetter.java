package com.reyansh.audio.audioplayer.free.Utils;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}