package com.reyansh.audio.audioplayer.free.Interfaces;

/**
 * Created by REYANSH on 19/09/2016.
 */
public interface OnContextItemSelectedListener {
    void OnContextItemSelected(int itemId);
}
